# Author: Martin Wegmann

# Date: February 2024

# content: .png files

# Comment:

# So we see the weird sampling in many, but not all univariate runs. We see them spread across linear (UVl), inverse (UVi) and variance-based (UVv) penalties. 
# Where I have not seen them so far is 1) in layers below the first one (except in UVvrun9N25pc5gap24.png) and 2) in runs with annual cycle as covariable. But those runs are not fully finished yet. Nevertheless I added an example plot from that experiment. 